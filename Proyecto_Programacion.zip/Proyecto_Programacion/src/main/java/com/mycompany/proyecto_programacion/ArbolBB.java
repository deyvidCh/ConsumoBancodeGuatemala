/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.proyecto_programacion;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

/**
 * author DEYVID
 */
public class ArbolBB {
    public Nodo raiz;

    public void insertar(double valor) {
        raiz = insertarNodo(raiz, valor);
    }

    public Nodo obtenerRaiz() {
        return raiz;
    }

    public int nodosCompletos(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }

        int count = 0;

        if (nodo.izquierdo != null && nodo.derecho != null) {
            count++;
        }

        count += nodosCompletos(nodo.izquierdo);
        count += nodosCompletos(nodo.derecho);

        return count;
    }

    private Nodo insertarNodo(Nodo nodo, double valor) {
        if (nodo == null) {
            return new Nodo(valor);
        }

        if (valor < nodo.getValor()) {
            nodo.setIzquierdo(insertarNodo(nodo.getIzquierdo(), valor));
        } else if (valor > nodo.getValor()) {
            nodo.setDerecho(insertarNodo(nodo.getDerecho(), valor));
        }

        return nodo;
    }

    public void pintar(Graphics g, int x, int y) {
        pintarNodo((Graphics2D) g, raiz, x, y);
    }

    private void pintarNodo(Graphics2D g2d, Nodo nodo, int x, int y) {
        if (nodo != null) {
            int radio = 20;
            int diametro = radio * 2;
            int espacio = 50;

            // Pintar el nodo actual
            g2d.setColor(Color.red);
            g2d.fillOval(x - radio, y - radio, diametro, diametro);
            g2d.setColor(Color.white);
            g2d.drawString(String.valueOf(nodo.getValor()), x - 5, y + 5);

            // Pintar los enlaces a los nodos hijos
            if (nodo.getIzquierdo() != null) {
                int xIzq = x - espacio;
                int yIzq = y + espacio;
                g2d.setColor(Color.blue);
                g2d.drawLine(x, y + radio, xIzq, yIzq - radio);
                pintarNodo(g2d, nodo.getIzquierdo(), xIzq, yIzq);
            }

            if (nodo.getDerecho() != null) {
                int xDer = x + espacio;
                int yDer = y + espacio;
                g2d.setColor(Color.blue);
                g2d.drawLine(x, y + radio, xDer, yDer - radio);
                pintarNodo(g2d, nodo.getDerecho(), xDer, yDer);
            }
        }
    }

    public List<Double> getPostOrden() {
        List<Double> postOrden = new ArrayList<>();
        recorridoPostOrden(raiz, postOrden);
        return postOrden;
    }

    public List<Double> getInOrden() {
        List<Double> inOrden = new ArrayList<>();
        recorridoInOrden(raiz, inOrden);
        return inOrden;
    }

    public List<Double> getPreOrden() {
        List<Double> preOrden = new ArrayList<>();
        recorridoPreOrden(raiz, preOrden);
        return preOrden;
    }

    private void recorridoPreOrden(Nodo nodo, List<Double> preOrden) {
        if (nodo != null) {
            preOrden.add(nodo.getValor());
            recorridoPreOrden(nodo.getIzquierdo(), preOrden);
            recorridoPreOrden(nodo.getDerecho(), preOrden);
        }
    }

    private void recorridoInOrden(Nodo nodo, List<Double> inOrden) {
        if (nodo != null) {
            recorridoInOrden(nodo.getIzquierdo(), inOrden);
            inOrden.add(nodo.getValor());
            recorridoInOrden(nodo.getDerecho(), inOrden);
        }
    }

    private void recorridoPostOrden(Nodo nodo, List<Double> postOrden) {
        if (nodo != null) {
            recorridoPostOrden(nodo.getIzquierdo(), postOrden);
            recorridoPostOrden(nodo.getDerecho(), postOrden);
            postOrden.add(nodo.getValor());
        }
    }

    public static class Nodo {
        private double valor;
        private Nodo izquierdo;
        private Nodo derecho;

        public Nodo(double valor) {
            this.valor = valor;
            izquierdo = null;
            derecho = null;
        }

        public double getValor() {
            return valor;
        }

        public Nodo getIzquierdo() {
            return izquierdo;
        }

        public void setIzquierdo(Nodo izquierdo) {
            this.izquierdo = izquierdo;
        }

        public Nodo getDerecho() {
            return derecho;
        }

        public void setDerecho(Nodo derecho) {
            this.derecho = derecho;
        }
    }
}





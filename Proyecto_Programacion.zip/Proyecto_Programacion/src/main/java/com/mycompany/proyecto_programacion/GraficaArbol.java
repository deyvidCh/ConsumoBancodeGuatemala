package com.mycompany.proyecto_programacion;

/**
 *
 * @author DEYVID
 */
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
import com.mycompany.proyecto_programacion.ArbolBB.Nodo;

public class GraficaArbol extends JPanel {
    private final ArbolBB miArbol;
    public static final int DIAMETRO = 40;
    public static int RADIO = DIAMETRO / 2;
    public static final int ANCHO = 50;

    public GraficaArbol(ArbolBB miArbol) {
        this.miArbol = miArbol;
        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        pintar(g, getWidth() / 2, 20, miArbol.obtenerRaiz());
    }

    private void pintar(Graphics g, int x, int y, Nodo r) {
        if (r == null) {
            return;
        }

        g.setColor(Color.white);
        int EXTRA = miArbol.nodosCompletos(r) * (ANCHO / 2);
        g.fillOval(x, y, DIAMETRO, DIAMETRO);
        g.setColor(Color.black);
        g.drawString(r.getValor() + "", x + 10, y + 20);
        g.setColor(Color.blue);
        if (r.getIzquierdo() != null) {
            g.drawLine(x + RADIO - 4, y + RADIO + 20, x - ANCHO - EXTRA + RADIO, y - 15 + ANCHO + RADIO);
        }
        if (r.getDerecho() != null) {
            g.drawLine(x + RADIO - 4, y + RADIO + 20, x + ANCHO + EXTRA + RADIO, y - 15 + ANCHO + RADIO);
        }
        pintar(g, x - ANCHO - EXTRA, y + ANCHO, r.getIzquierdo());
        pintar(g, x + ANCHO + EXTRA, y + ANCHO, r.getDerecho());
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto_programacion;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.io.StringReader;
import java.sql.*;
import com.google.gson.Gson;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import java.security.cert.CertificateException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.springframework.web.client.RestClientException;
import java.util.Stack;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;
import javax.swing.JOptionPane;


public class Proyecto_Programacion extends JFrame {

    private final JTable resultadosTable;
    private final JTextField fechaInicioField;
    private final JTextField fechaFinField;
    /*private final JTextField monedaField;*/
    private final JComboBox<String> monedaComboBox;

    public Proyecto_Programacion() {
        super("Consumo WebService Banguat");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 400);
        setLayout(new BorderLayout());
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel fechaPanel = new JPanel();
        fechaPanel.setLayout(new GridLayout(4, 2, 5, 5));

        JLabel fechaInicioLabel = new JLabel("Fecha Inicial dd/mm/yyyy:");
        fechaInicioField = new JTextField();

        JLabel fechaFinLabel = new JLabel("Fecha Final dd/mm/yyyy:");
        fechaFinField = new JTextField();

        JLabel monedaLabel = new JLabel("Tipo de Moneda:");
        monedaComboBox = new JComboBox<>(new String[]{
            "DOLAR=2",
            "YENES JAPONESES=3",
            "FRANCOS SUIZOS=5",
            "DÓLARES CANADIENSES=7",
            "LIBRAS ESTERLINAS=9",
            "CORONAS SUECAS=15",
            "COLONES COSTARRICENSES=16",
            "COLONES SALVADOREÑOS=17",
            "PESOS MEXICANOS=18",
            "LEMPIRAS HONDUREÑOS=19",
            "CÓRDOBAS NICARAGÜENSES=21",
            "CORONA DANESA=23",
            "EURO=24",
            "CORONA NORUEGA=25",
            "DEG=26",
            "PESO ARGENTINO=29",
            "REAL BRASILEÑO=30",
            "WON COREANO=31",
            "DÓLAR HONG KONG=32",
            "DÓLAR TAIWÁN=33",
            "YUAN CHINA=34",
            "RUPIA PAKISTÁN=35",
            "RUPEE INDIA=36",
            "PESO COLOMBIANO=38",
            "PESO DOMINICANO=39",
            "RINGGIT MALASIA=40",
            "BOLÍVAR SOBERANO=41"
        });

        fechaPanel.add(fechaInicioLabel);
        fechaPanel.add(fechaInicioField);
        fechaPanel.add(fechaFinLabel);
        fechaPanel.add(fechaFinField);
        fechaPanel.add(monedaLabel);
        fechaPanel.add(monedaComboBox);

        panel.add(fechaPanel, BorderLayout.NORTH);
        
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 3, 10, 0));
        
        
        JButton obtenerButton = new JButton("Obtener cambio");
       obtenerButton.addActionListener((ActionEvent e) -> {
    try {
        String fechaInicio = fechaInicioField.getText();
        String fechaFin = fechaFinField.getText();
        String monedaOption = (String) monedaComboBox.getSelectedItem();

        if (fechaInicio.isEmpty() || fechaFin.isEmpty() || monedaOption.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar las fechas de inicio, fin y el tipo de moneda.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Extrae el valor de la opción seleccionada
        String[] parts = monedaOption.split("=");
        String monedaIngresada = parts[1].trim();

        obtenerResultados(fechaInicio, fechaFin, monedaIngresada);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al obtener los resultados.", "Error", JOptionPane.ERROR_MESSAGE);
    }
});
        
        JButton eliminarButton = new JButton("Eliminar datos");
        eliminarButton.addActionListener((ActionEvent e) -> {
            try {
        eliminarDatos();
        } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al eliminar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
    }
});

        buttonPanel.add(eliminarButton);


        JButton mostrarAPIButton = new JButton("Mostrar Api-Rest");
        mostrarAPIButton.addActionListener((ActionEvent e) -> {
            try {
                mostrarAPI();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error al mostrar los resultados de la API.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Crear el botón "Mostrar Árbol"
        JButton mostrarArbolButton = new JButton("Mostrar Árbol");
        mostrarArbolButton.addActionListener((ActionEvent e) -> {
        try {
        // Crear el árbol
        ArbolBB arbol = new ArbolBB();

        // Realizar la solicitud HTTP al API REST
        URL url = new URL("https://localhost:5001/api/cambio");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();

        // Leer la respuesta del API REST
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        conn.disconnect();

        // Analizar la respuesta JSON
        JSONArray jsonArray = new JSONArray(response.toString());

        // Obtener los valores de compra desde la respuesta y agregarlos al árbol
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            double valorCompra = jsonObject.getDouble("compra");
            arbol.insertar(valorCompra);
        }

        // Crear la ventana para mostrar el árbol
        JFrame frame = new JFrame("Árbol BB");
        frame.setSize(800, 600);

        // Crear el componente visual para mostrar el árbol
        GraficaArbol graficaArbol = new GraficaArbol(arbol);
        frame.add(graficaArbol);

        // Crear el JTextArea para mostrar los recorridos
        JTextArea recorridosTextArea = new JTextArea();
        recorridosTextArea.setEditable(false);

        // Establecer el tamaño preferido del JTextArea
        recorridosTextArea.setPreferredSize(new Dimension(300, 100));
        
        // Establecer la fuente y el tamaño de letra
        Font font = new Font("Arial", Font.PLAIN, 16); // Cambia "Arial" y 16 por la fuente y tamaño deseados
        recorridosTextArea.setFont(font);
        
        // Crear el JScrollPane para agregar el JTextArea con scroll
        JScrollPane scrollPane = new JScrollPane(recorridosTextArea);
        frame.add(scrollPane, BorderLayout.SOUTH);

        // Crear los botones de postorden, inorden y preorden
        JButton postOrdenButton = new JButton("Postorden");
        JButton inOrdenButton = new JButton("Inorden");
        JButton preOrdenButton = new JButton("Preorden");

        // Agregar ActionListener al botón "Postorden"
        postOrdenButton.addActionListener((ActionEvent postEvent) -> {
            List<Double> postOrden = arbol.getPostOrden();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < postOrden.size(); i++) {
                sb.append(postOrden.get(i));
                if (i != postOrden.size() - 1) {
                    sb.append("; "); // Agrega una coma (",") si no es el último valor
                }
            }
            recorridosTextArea.setText("Recorrido en Postorden: " + sb.toString());
        });

        // Agregar ActionListener al botón "Inorden"
        inOrdenButton.addActionListener((ActionEvent inEvent) -> {
            List<Double> inOrden = arbol.getInOrden();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < inOrden.size(); i++) {
                sb.append(inOrden.get(i));
                if (i != inOrden.size() - 1) {
                    sb.append("; "); // Agrega una coma (",") si no es el último valor
                }
            }
            recorridosTextArea.setText("Recorrido en Inorden: " + sb.toString());
        });

        // Agregar ActionListener al botón "Preorden"
        preOrdenButton.addActionListener((ActionEvent preEvent) -> {
            List<Double> preOrden = arbol.getPreOrden();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < preOrden.size(); i++) {
                sb.append(preOrden.get(i));
                if (i != preOrden.size() - 1) {
                    sb.append("; "); // Agrega una coma (",") si no es el último valor
                }
            }
            recorridosTextArea.setText("Recorrido en Preorden: " + sb.toString());
        });

        // Crear un JPanel para los botones de recorridos
        JPanel recorridosPanel = new JPanel();
        recorridosPanel.add(postOrdenButton);
        recorridosPanel.add(inOrdenButton);
        recorridosPanel.add(preOrdenButton);
        frame.add(recorridosPanel, BorderLayout.NORTH);

        // Mostrar la ventana con el árbol
        frame.setVisible(true);

    } catch (MalformedURLException ex) {
        JOptionPane.showMessageDialog(null, "Error al mostrar el árbol. La URL del API REST es incorrecta.", "Error", JOptionPane.ERROR_MESSAGE);
        System.out.println("Error al mostrar el árbol. La URL del API REST es incorrecta.");
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(null, "Error al mostrar el árbol. No se pudo conectar al API REST.", "Error", JOptionPane.ERROR_MESSAGE);
        System.out.println("Error al mostrar el árbol. No se pudo conectar al API REST.");
    } catch (JSONException ex) {
        JOptionPane.showMessageDialog(null, "Error al mostrar el árbol. La respuesta del API REST no es válida.", "Error", JOptionPane.ERROR_MESSAGE);
        System.out.println("Error al mostrar el árbol. La respuesta del API REST no es válida.");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Error al mostrar el árbol.", "Error", JOptionPane.ERROR_MESSAGE);
        System.out.println("Error al mostrar el árbol.");
    }
});



            buttonPanel.add(obtenerButton);
            buttonPanel.add(mostrarAPIButton);
            buttonPanel.add(mostrarArbolButton);
            buttonPanel.add(eliminarButton);
            panel.add(buttonPanel, BorderLayout.CENTER);
            add(panel, BorderLayout.NORTH);

            resultadosTable = new JTable();
            JScrollPane scrollPane = new JScrollPane(resultadosTable);
            add(scrollPane, BorderLayout.CENTER);

        add(scrollPane, BorderLayout.CENTER);
    }
    


public void mostrarAPI() {
    try {
        TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                }
                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) throws CertificateException {
                    // Implementa la verificación del certificado del servidor aquí
                    // Puedes lanzar una CertificateException si el certificado no es válido o confiable
                }
            }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLHostnameVerifier(new NoopHostnameVerifier())
                .build();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setHttpClient(httpClient);
        RestTemplate restTemplate = new RestTemplate(requestFactory);

        ResponseEntity<String> response = restTemplate.getForEntity("https://localhost:5001/api/cambio", String.class);
        if (response.getStatusCode().is2xxSuccessful()) {
            Gson gson = new Gson();
            Moneda[] monedas = gson.fromJson(response.getBody(), Moneda[].class);

            DefaultTableModel model = new DefaultTableModel();
            model.setColumnIdentifiers(new Object[]{"Fecha", "Moneda", "Compra", "Venta"});

            Stack<Moneda> pila = new Stack<>();
            int totalPush = 0;
            int totalPop = 0;

            for (Moneda moneda : monedas) {
                pila.push(moneda);
                totalPush++;
                JOptionPane.showMessageDialog(null, "Elemento ingresado (push): " + moneda.getFecha()+ " | " +  moneda.getCompra(), "Push", JOptionPane.INFORMATION_MESSAGE);
            }

            while (!pila.isEmpty()) {
                Moneda moneda = pila.pop();
                totalPop++;
                System.out.println("Elemento eliminado (pop): " + moneda.getMoneda());
                model.addRow(new Object[]{moneda.getFecha(), moneda.getMoneda(), moneda.getCompra(), moneda.getVenta()});
            }

            resultadosTable.setModel(model);

            JOptionPane.showMessageDialog(null, "Resultados de la API mostrados correctamente.\nTotal de elementos ingresados (push): " + totalPush + "\nTotal de elementos eliminados (pop): " + totalPop, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error al mostrar los resultados de la API. Código de estado: " + response.getStatusCodeValue(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (RestClientException | NoSuchAlgorithmException | KeyManagementException e) {
        JOptionPane.showMessageDialog(null, "Error desconocido al mostrar los resultados de la API. Detalles: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        System.err.println("Error desconocido al mostrar los resultados de la API. Detalles: " + e.getMessage());
    }
}

    public void eliminarDatos() {
    try {
        // Configura los detalles de la conexión a tu base de datos MySQL
        String url = "jdbc:mysql://localhost:3306/tipocambiobanguat";
        String usuario = "root";
        String contraseña = "Umg-2023";

        // Establece la conexión
        try (Connection conn = DriverManager.getConnection(url, usuario, contraseña)) {
            // Crea la consulta de eliminación
            String consulta = "DELETE FROM valoresdelws";
            Statement statement = conn.createStatement();

            // Ejecuta la consulta de eliminación
            int rowCount = statement.executeUpdate(consulta);

            if (rowCount > 0) {
                // Reinicia el campo autoincrementable
                String reiniciarAutoincremento = "ALTER TABLE valoresdelws AUTO_INCREMENT = 1";
                statement.executeUpdate(reiniciarAutoincremento);

                JOptionPane.showMessageDialog(null, "Datos eliminados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

                // Limpia el modelo de tabla
                DefaultTableModel model = (DefaultTableModel) resultadosTable.getModel();
                model.setRowCount(0);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron datos para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

    public void obtenerResultados(String fechaInicio, String fechaFin, String monedaIngresada) throws Exception {
        if (fechaInicio.isEmpty() || fechaFin.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar las fechas de inicio y fin.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Uso del servicio TIPOCAMBIORANGOMONEDA del Banguat
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.post("https://www.banguat.gob.gt/variables/ws/TipoCambio.asmx")
                    .header("Content-Type", "text/xml; charset=utf-8")
                    .body("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                            "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                            "  <soap:Body>\n" +
                            "    <TipoCambioRangoMoneda xmlns=\"http://www.banguat.gob.gt/variables/ws/\">\n" +
                            "      <fechainit>" + fechaInicio + "</fechainit>\n" +
                            "      <fechafin>" + fechaFin + "</fechafin>\n" +
                            "      <moneda>" + monedaIngresada + "</moneda>\n" +
                            "    </TipoCambioRangoMoneda>\n" +
                            "  </soap:Body>\n" +
                            "</soap:Envelope>")
                    .asString();

            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(response.getBody()));

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(is);
            NodeList nodes = doc.getElementsByTagName("Var");

            DefaultTableModel model = new DefaultTableModel(new Object[]{"Fecha", "Moneda", "Compra", "Venta"}, 0);

            // Configura los detalles de la conexión a tu base de datos MySQL
            String url = "jdbc:mysql://localhost:3306/tipocambiobanguat";
            String usuario = "root";
            String contraseña = "Umg-2023";

            // Establece la conexión
            try (Connection conn = DriverManager.getConnection(url, usuario, contraseña)) {
                // Crea la consulta de inserción
                String consulta = "INSERT INTO valoresdelws (idvaloresdelws, fecha, moneda, compra, venta) VALUES (NULL, ?, ?, ?, ?)";
                PreparedStatement statement = conn.prepareStatement(consulta, Statement.RETURN_GENERATED_KEYS);

                // Verifica si la fecha ya existe en la tabla
                String verificarFecha = "SELECT COUNT(*) FROM valoresdelws WHERE fecha = ?";
                PreparedStatement verificarStatement = conn.prepareStatement(verificarFecha);
                verificarStatement.setString(1, fechaInicio); // Verificar la fecha de inicio en lugar de cada fecha en el bucle

                ResultSet resultado = verificarStatement.executeQuery();
                resultado.next();
                int count = resultado.getInt(1);

                if (count > 0) {
                    JOptionPane.showMessageDialog(null, "La fecha ingresada ya existe.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Inserta los datos en la tabla
                for (int i = 0; i < nodes.getLength(); i++) {
                    Element element = (Element) nodes.item(i);

                    String fecha = element.getElementsByTagName("fecha").item(0).getTextContent().trim();
                    String moneda = element.getElementsByTagName("moneda").item(0).getTextContent().trim();
                    String compra = element.getElementsByTagName("compra").item(0).getTextContent().trim();
                    String venta = element.getElementsByTagName("venta").item(0).getTextContent().trim();

                    statement.setString(1, fecha);
                    statement.setString(2, moneda);
                    statement.setString(3, compra);
                    statement.setString(4, venta);

                    // Ejecuta la consulta de inserción
                    statement.executeUpdate();

                    // Agrega los datos al modelo de tabla
                    model.addRow(new Object[]{fecha, moneda, compra, venta});
                }

                // Muestra los resultados en la interfaz
                resultadosTable.setModel(model);

                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int idValoresDelWS = generatedKeys.getInt(1);
                    // Haz algo con el idValoresDelWS generado
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            System.out.println("Respuesta: " + response.getBody());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Proyecto_Programacion consumo = new Proyecto_Programacion();
            consumo.setVisible(true);
        });
    }
}
